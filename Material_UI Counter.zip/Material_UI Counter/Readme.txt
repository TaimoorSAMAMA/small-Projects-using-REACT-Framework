I have made Counter using Material UI Special incremental and Decremental icons
in which when you will click on a inc button the Count will increase by one and 
when you will click on Reset button the Count is reset to zero(0).
I used React Framework.