import React, { useState } from "react";
import "./index.css";
import Button from "@material-ui/core/Button";

const App = () => {
  const [count, setCount] = useState(0);

  const IncNum = () => {
    setCount(count + 1);
  };

  const DecNum = () => {
    setCount(0);
  };
  return (
    <>
      <h1 className="head">COUNTER</h1>
      <div className="clicking parent_div">
        <h1 className="count_center ">{count}</h1>
        <Button onClick={IncNum} className="button_inc hover-button">
          Click me
        </Button>
        <Button onClick={DecNum} className="reset_count">
          Reset
        </Button>
      </div>
    </>
  );
};

export default App;
