// Input field code with multiple inputs.(spred operator).
import React from "react";
import { useState } from "react";
import "./index.css";
const App = () => {
  const [fullName, setFullName] = useState({
    fname: "",
    lname: "",
    email: "",
    phoneno: "",
  });

  const onSubmit = (evt) => {
    evt.preventDefault();
    alert("form submitted");
  };

  const inputevent = (event) => {
    console.log(event.target.value);
    console.log(event.target.name);

    const { value, name } = event.target;

    setFullName((preValue) => {
      return {
        ...preValue,
        [name]: value,
      };
    });
  };
  return (
    <>
      <div className="container">
        <form onSubmit={onSubmit}>
          <h1 className="fs">
            Hello {fullName.fname} {fullName.lname}
            <p>{fullName.email}</p>
            <p>{fullName.phoneno}</p>
          </h1>
          <input
            type="text"
            placeholder="Enter your First Name"
            defaultValue=""
            name="fname"
            onChange={inputevent}
            value={fullName.fname}
          />
          <br />
          <input
            type="text"
            placeholder="Enter your Last Name"
            defaultValue=""
            name="lname"
            onChange={inputevent}
            value={fullName.lname}
          />
          <input
            type="email"
            placeholder="Enter your email"
            defaultValue=""
            name="email"
            onChange={inputevent}
            value={fullName.email}
            autoComplete="off"
          />
          <input
            type="number"
            placeholder="Enter your Phone number"
            defaultValue=""
            name="phoneno"
            onChange={inputevent}
            value={fullName.phoneno}
          />
          <button type="submit">
            {/* onClick={onSubmit} */}
            Click me
          </button>
        </form>
      </div>
    </>
  );
};

export default App;
