I have made a input field for First, Last Names, Email and Phone number with Email and Phone number Validations.
I have made it using Spred Operator.
I used React Framework.