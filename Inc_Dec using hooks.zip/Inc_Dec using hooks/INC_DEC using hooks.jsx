import React, { useState } from "react";
import AddIcon from "@material-ui/icons/Add";
import RemoveIcon from "@material-ui/icons/Remove";
import "./index.css";

const App = () => {
  const [count, setCount] = useState(0);

  const IncNum = () => {
    setCount(count + 1);
  };

  const DecNum = () => {
    if (count > 0) {
      setCount(count - 1);
    } else {
      setCount(0);
    }
  };

  return (
    <>
      <div className="main_div">
        <div className="center_div">
          <h1>Counter</h1>
          <h1 className="clr">{count}</h1>
          <div className="btn_div">
            <button onClick={IncNum}>
              <AddIcon />
            </button>
            <button onClick={DecNum}>
              <RemoveIcon />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default App;
