// Clock
// import React, { useState } from 'react';
// import './index.css'
// const App = () =>
// {
//     let currtime = new Date().toLocaleTimeString();
//     const [ctime, setCtime] = useState(currtime);

//     const UpdateTime = () =>{
//         currtime = new Date().toLocaleTimeString();
//         setCtime(currtime);
//     }
//    return(
//     <>
//        <h1 className='H1'>{ctime}</h1>
//        <button onClick={UpdateTime} className='BTN'> GET TIME</button>
//     </>
//    );
// }
// export default App;
////////////////////////////////////////////////////////////////////////////////////////
// DIGITAL CLOCK
// import React, { useState } from 'react';
// import './index.css'

// const App = () =>{

//    let time = new Date().toLocaleTimeString();

//    const [currtime, setctime] = useState(time);
//    // first arg is current & 2nd arg is updated..

//    const updatetime = () =>{
//     let time = new Date().toLocaleTimeString();
//     setctime(time);
//    };

//    setInterval(updatetime,1000);

//    return(
//     <>
//         <h1> {currtime}</h1>
//         {/* <button onClick={updatetime}> get time </button> */}
//     </>
//    );
// }

// export default App;
