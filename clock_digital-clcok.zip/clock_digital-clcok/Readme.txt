I have made Clock that on clicking the button provided on React App Screen gives you the time of your pc 
and I have made Digital CLock that runs according to your pc time.
I used React Framework.