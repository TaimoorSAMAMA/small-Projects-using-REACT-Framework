I have made a greeting Thing that will greet you according to time on your PC.
I used React Framework.