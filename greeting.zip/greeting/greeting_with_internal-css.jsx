// Greeting Thing
import React from "react";

function App() {
  let currDate = new Date();
  currDate = currDate.getHours();
  let cssStyle = {};
  let greeting = "";

  const sty = {
    height: "100px",
    width: "700px",
    color: "rgb(204, 51, 255)",
    backgroundColor: "coral",
    border: "2px solid blue",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginTop: "280px",
    marginLeft: "320px",
    borderRadius: "20px",
  };
  if (currDate >= 1 && currDate < 12) {
    greeting = "Good Morning!";
    cssStyle.color = "green";
  } else if (currDate >= 12 && currDate < 19) {
    greeting = "Good Evening!";
    cssStyle.color = "Orange";
  } else {
    greeting = "Good Night!";
    cssStyle.color = "Black";
  }

  return (
    <>
      <h1 style={sty}>
        As Salam o Alaikum Sir, <span style={cssStyle}>{greeting}</span>
      </h1>
    </>
  );
}

export default App;
